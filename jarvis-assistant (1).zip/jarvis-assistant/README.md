# Jarvis – Voice Assistant in Python

A desktop voice assistant built with Python. The GUI uses web technologies (HTML, CSS, JavaScript) through the [Eel](https://github.com/python-eel/Eel) library.

Inspired by the playlist "How to make Jarvis | Voice Assistant in Python" by [ProjectsWithDigambar](https://www.youtube.com/playlist?list=PL5KqGf90H2zvu53fkuLuomo-NwZEI6m3C).

## Features
- Voice commands (microphone) or typed commands
- Text-to-speech replies
- Open websites and Windows apps: "open youtube", "open notepad"
- Play videos on YouTube: "play believer on youtube"
- Google search: "search python tutorials"
- Wikipedia answers: "who is Albert Einstein"
- Time and date: "what is the time", "what is today's date"

## Project structure
```
jarvis-assistant/
├── main.py              # starts the app
├── engine/
│   └── features.py      # speak, listen, command handling
├── www/
│   ├── index.html       # GUI
│   ├── style.css
│   └── script.js
├── requirements.txt
├── run.bat / run.sh     # one-click start
└── README.md
```

## Setup
Requires Python 3.10+ (tick "Add Python to PATH" when installing), internet, and Chrome or Edge.

**Easiest way**
- Windows: double-click `run.bat`
- Mac/Linux: run `./run.sh`

It creates a virtual environment, installs everything and starts Jarvis.

**Manual way**
```bash
git clone https://github.com/YOUR-USERNAME/jarvis-assistant.git
cd jarvis-assistant
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # Mac/Linux
pip install -r requirements.txt
python main.py
```

## Microphone support
Typed commands always work. For voice input install PyAudio:
- Windows: `pip install PyAudio`
- Linux: `sudo apt install portaudio19-dev espeak` then `pip install PyAudio`
- Mac: `brew install portaudio` then `pip install PyAudio`

## Ideas to extend
- Weather, news, or jokes
- Send WhatsApp messages
- Wake word ("Hey Jarvis")
- AI chat replies using an LLM API (keep keys in a `.env` file)

## License
MIT

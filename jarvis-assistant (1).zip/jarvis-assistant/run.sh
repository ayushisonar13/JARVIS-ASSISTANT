#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -d venv ] || python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install PyAudio || echo "PyAudio failed - you can still type commands."
python main.py

const chat = document.getElementById("chat");
const status = document.getElementById("status");
const orb = document.getElementById("orb");
const input = document.getElementById("textInput");

function addMessage(text, cls) {
  const div = document.createElement("div");
  div.className = "msg " + cls;
  div.textContent = text;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

// Functions below are called from Python
eel.expose(DisplayMessage);
function DisplayMessage(msg) { status.textContent = msg; orb.classList.add("active"); }

eel.expose(senderText);
function senderText(msg) { addMessage(msg, "me"); }

eel.expose(receiverText);
function receiverText(msg) { addMessage(msg, "bot"); }

eel.expose(ShowHood);
function ShowHood() { status.textContent = "Click the mic and speak"; orb.classList.remove("active"); }

document.getElementById("micBtn").onclick = () => eel.start_listening();

function sendTyped() {
  const text = input.value.trim();
  if (!text) return;
  input.value = "";
  eel.send_text(text);
}
document.getElementById("sendBtn").onclick = sendTyped;
input.addEventListener("keydown", e => { if (e.key === "Enter") sendTyped(); });

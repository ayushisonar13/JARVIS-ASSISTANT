"""Core features of Jarvis: speaking, listening and handling commands."""
import datetime
import json
import os
import platform
import urllib.parse
import urllib.request
import webbrowser

import eel

# Websites Jarvis can open by name
WEBSITES = {
    "youtube": "https://www.youtube.com",
    "google": "https://www.google.com",
    "github": "https://www.github.com",
    "gmail": "https://mail.google.com",
    "facebook": "https://www.facebook.com",
    "instagram": "https://www.instagram.com",
    "whatsapp": "https://web.whatsapp.com",
    "linkedin": "https://www.linkedin.com",
}

# Desktop apps (Windows only)
APPS = {
    "notepad": "notepad",
    "calculator": "calc",
    "paint": "mspaint",
}


def speak(text):
    """Show the text in the GUI and say it out loud (if speech works)."""
    text = str(text)
    print("Jarvis:", text)
    eel.receiverText(text)
    try:
        import pyttsx3
        engine = pyttsx3.init()
        engine.setProperty("rate", 170)
        engine.say(text)
        engine.runAndWait()
    except Exception as e:  # never crash if the voice engine fails
        print("Voice output not available:", e)


def take_command():
    """Listen from the microphone and return the text (lowercase)."""
    try:
        import speech_recognition as sr
    except ImportError:
        speak("SpeechRecognition is not installed. Please type your command.")
        return ""

    recognizer = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            eel.DisplayMessage("Listening...")
            recognizer.pause_threshold = 1
            recognizer.adjust_for_ambient_noise(source, duration=0.5)
            audio = recognizer.listen(source, timeout=8, phrase_time_limit=7)
        eel.DisplayMessage("Recognizing...")
        query = recognizer.recognize_google(audio, language="en-in")
        eel.senderText(query)
        return query.lower()
    except sr.WaitTimeoutError:
        speak("I didn't hear anything.")
    except sr.UnknownValueError:
        speak("Sorry, I couldn't understand that.")
    except sr.RequestError:
        speak("Speech service is unavailable. Check your internet.")
    except (OSError, AttributeError):
        speak("Microphone is not available (PyAudio may be missing). "
              "You can type your command instead.")
    return ""


def wikipedia_summary(topic):
    """Get a short summary from Wikipedia without extra libraries."""
    url = ("https://en.wikipedia.org/api/rest_v1/page/summary/"
           + urllib.parse.quote(topic.strip().replace(" ", "_")))
    req = urllib.request.Request(url, headers={"User-Agent": "JarvisAssistant/1.0"})
    with urllib.request.urlopen(req, timeout=8) as resp:
        data = json.load(resp)
    return data.get("extract") or "I couldn't find that on Wikipedia."


def open_something(name):
    name = name.strip()
    if name in WEBSITES:
        speak(f"Opening {name}")
        webbrowser.open(WEBSITES[name])
    elif name in APPS and platform.system() == "Windows":
        speak(f"Opening {name}")
        os.system(f"start {APPS[name]}")
    else:
        speak(f"Searching for {name}")
        webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(name))


def handle_query(query):
    """Decide what to do with a command."""
    query = (query or "").lower().strip()
    if not query:
        return

    if query.startswith("open "):
        open_something(query[5:])

    elif query.startswith("play "):
        song = query[5:].replace("on youtube", "").strip()
        speak(f"Searching {song} on YouTube")
        webbrowser.open("https://www.youtube.com/results?search_query="
                        + urllib.parse.quote(song))

    elif "time" in query:
        speak("It is " + datetime.datetime.now().strftime("%I:%M %p"))

    elif "date" in query or "today" in query:
        speak("Today is " + datetime.datetime.now().strftime("%A, %d %B %Y"))

    elif query.startswith("search "):
        term = query[7:]
        speak(f"Searching Google for {term}")
        webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(term))

    elif query.startswith(("who is ", "what is ", "tell me about ")):
        for prefix in ("who is ", "what is ", "tell me about "):
            if query.startswith(prefix):
                topic = query[len(prefix):]
        try:
            speak(wikipedia_summary(topic))
        except Exception:
            speak("I couldn't find that on Wikipedia. Check your internet.")

    elif "hello" in query or query.startswith("hi"):
        speak("Hello! How can I help you?")

    elif query in ("exit", "quit", "stop", "bye", "goodbye"):
        speak("Goodbye! Have a great day.")

    else:
        speak("Sorry, I don't know that command yet.")


@eel.expose
def start_listening():
    """Called from the mic button in the GUI."""
    handle_query(take_command())
    eel.ShowHood()


@eel.expose
def send_text(text):
    """Called when the user types a command in the GUI."""
    eel.senderText(text)
    handle_query(text)
    eel.ShowHood()

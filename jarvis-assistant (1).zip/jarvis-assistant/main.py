import os
import sys

import eel

from engine import features  # noqa: F401  (registers the exposed functions)


def main():
    # Always work relative to this file, no matter where you run it from
    base = os.path.dirname(os.path.abspath(__file__))
    eel.init(os.path.join(base, "www"))

    print("Starting Jarvis... a browser window will open.")
    for mode in ("chrome", "edge", "default"):
        try:
            eel.start("index.html", mode=mode, size=(480, 720), port=0)
            return
        except (EnvironmentError, OSError) as e:
            print(f"Could not start with '{mode}':", e)
    print("Could not open a browser. Please install Chrome or Edge.")
    sys.exit(1)


if __name__ == "__main__":
    main()

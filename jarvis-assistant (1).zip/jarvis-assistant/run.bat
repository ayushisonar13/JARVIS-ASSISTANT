@echo off
cd /d "%~dp0"
if not exist venv (
  echo Creating virtual environment...
  python -m venv venv
)
call venv\Scripts\activate
echo Installing requirements...
pip install -r requirements.txt
echo Installing microphone support (optional)...
pip install PyAudio || echo PyAudio failed - you can still type commands.
python main.py
pause
